# Prueba de Utilización de Git:

Este repositorio es para aprender a utilizar GitHub Repo
que es una herramienta para version control. Este repo
contiene una base de datos de ejemplo de Precio de Venta
de Motocicletas.

by Camilo Duque
Universidad de los Andes (c) 2024
Analitica Computacional para la Toma de Decisiones
